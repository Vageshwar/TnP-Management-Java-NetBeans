
package testing;



public class Testing {
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        GUI o = new GUI();
        o.setVisible(true);
    }
    
}
